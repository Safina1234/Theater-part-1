/*CreditCard class holds credit info for customers
 * @author @author Brahma Dathan and Sarnath Ramnath
 */
import java.io.Serializable;
import java.util.Iterator;
import java.util.LinkedList;

public class CreditCard implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String cardNumber;
	private String id;
	private LinkedList<CreditCard> listOfCard = new LinkedList<CreditCard>();

	
	/**
	*returns id
	*@return id
	*/
	public String getId() {
		return id;
	}
	
	/**
	*sets id
	*@param id
	*/
	public void setId(String id) {
		this.id = id;
	}

	private String date;
	
	/**
	*creates CreditCard
	*@param id
	*@param cardNumber
	*@param date
	*/
	public CreditCard(String id, String cardNumber, String date) {
		super();
		this.id = id;
		this.cardNumber = cardNumber;
		this.date = date;
	}
	/**
	*returns cardNumber
	*@return cardNumber
	*/
	public String getCardNumber() {
		return cardNumber;
	}
	
	/**
	*sets cardNumber
	*@param cardNumber
	*/
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	
	/**
	*returns date
	*@param date
	*/
	public String getDate() {
		return date;
	}

	/**
	*sets date
	*@param
	*/
	public void setDate(String date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "CreditCard [cardNumber=" + cardNumber + ", date=" + date + "]";
	}
	
	/**
	*searches list for card
	*@param clientId
	*@return card
	*/
	public CreditCard search(String clientId) {
		  for(
			Iterator<CreditCard> iterator = listOfCard.iterator(); iterator.hasNext(); ) {
		    CreditCard card = (CreditCard) iterator.next();
		    if (card.getCardNumber().equals(clientId)) {
		      return card;
		    }
		  }
		  return null;
		}
	

}

