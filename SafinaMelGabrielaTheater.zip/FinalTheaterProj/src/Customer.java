/**
 * Customer class keeps track of customer personal info
 * @author @author Brahma Dathan and Sarnath Ramnath
 */
import java.io.Serializable;
import java.util.List;

public class Customer implements Serializable {
	private String name;
	private String address;
	private String phone;
	private String id;
	private static final long serialVersionUID = 1L;

	private static final String CUSTOMER_STRING = "G";
	
	/**
	*Creates constructor for Customer
	 * @param name
	 * @param address
	 * @param phone
	 */

	public Customer(String name, String address, String phone) {
	
		this.name = name;
		this.address = address;
		this.phone = phone;
		id = CUSTOMER_STRING + (CustomerIDServer.instance().getId());

	}
	/**
	*checks if id equals
	*@param id
	*/
	public boolean equals(String id) {
		return this.id.equals(id);
	}
	/**
	*returns phone
	*@return name
*/
	public String getName() {
		return name;
	}
	/**
	*sets name
	*@param name
	*/
	public void setName(String name) {
		this.name = name;
	}
	/**
	*returns address
	*@return address
	*/
	public String getAddress() {
		return address;
	}
	/**
	*sets address
	*@param address
	*/
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	*returns phone
	*@return phone
	*/	
	public String getPhone() {
		return phone;
	}
	
	/**
	*sets phone
	*@param phone
	*/
	public void setPhone(String phone) {
		this.phone = phone;
	}

	/**
	*returns id
	*@return id
	*/
	public String getId() {
		return id;
	}
	/**
	*sets id
	*@param id
	*/
	public void setId(String id) {
		this.id = id;
	}
	
	@Override
	public String toString() {
		return "Customer [name=" + this.getName() + ", address=" + this.getAddress() + ", phone=" + this.getPhone() + ", id=" + this.getId() + "]";
	}
	
	
}

