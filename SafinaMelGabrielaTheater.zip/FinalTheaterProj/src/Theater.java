/**Theater class is where client, customer and show info comes from
 * @author Brahma Dathan and Sarnath Ramnath
**/
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Calendar;
import java.util.Iterator;

public class Theater implements Serializable {
	
	 private CLientList clientList;
	 private CustomerList customerList;	
	 private ShowList showList;
	private CreditCardList creditCardList;

	  private static Theater theater;
	  
	  /**
	   * Private for the singleton pattern
	   * Creates the catalog and member collection objects
	   */
	  private Theater() {
	 
	    clientList = CLientList.instance();
	    customerList = CustomerList.instance();
	    showList = ShowList.instance();
     creditCardList = CreditCardList.instance();
	  }
	  /**
	   * Supports the singleton pattern
	   * 
	   * @return the singleton object
	   */
	  public static Theater instance() {
	    if (theater == null) {
	      ClientIDServer.instance(); // instantiate all singletons
	      CustomerIDServer.instance();
	      return (theater = new Theater());
	    } else {
	      return theater;
	    }
	  }
	  
	  /**
	   * adds a client to the clientList
	   * @param name, address,phone
	   * @return the client
	   */
	  
	  public Client addClient(String name, String address, String phone) {
		    Client client = new Client(name, address, phone);
		    if (clientList.insertClient(client)) {
		      return (client);
		    }
		    return null;
		  }
	  
	  /**
	   * Searches for a specific client using an Id
	   * @param clientId
	   * @return returns the client with that id
	   */
	  
	  public Client searchClient(String clientId) {
		    return clientList.search(clientId);
		  }
	  
	 public Show searchShow(String clientID){
	      return showList.search(clientID);
	}
	  
	  /**
	   * Removes a client from the clientList
	   * @param client
	   * doesn't return anything
	   */
	  
	 public void removeClient(Client client) {
		  
		  clientList.deleteClient(client);
		  
		  	  }
	
	  
	  /**
	   * Displays the clientList
	   * 
	   * doesn't return anything
	   */
	  public void displayClients() {
		  
		  clientList.displayClientsTheater();
	  }
	  
	/**
	*adds customer to customerList
	*@param name
	*@param address
	*@param phone
	*@param creditNumber
	*@param creditDate
	*@return customer
	*/
	  public Customer addCustomer(String name, String address, String phone, String creditNumber, String creditDate) {
		  Customer customer = new Customer(name, address, phone);
		  CreditCard card = new CreditCard(customer.getId(), creditNumber, creditDate);
		  creditCardList.addCard(card);
		  if(customerList.insertedCustomer(customer)) {
			  return customer;
		  }
		  return null;
	  }

	  
	
	  
	  public ShowList displayShows() {
		 return showList;
		  
	  }

	  /**
	   * Retrieves a deserialized version of the library from disk
	   * @return a Library object
	   */
	  public static Theater retrieve() {
	    try {
	      FileInputStream file = new FileInputStream("TheaterData");
	      ObjectInputStream input = new ObjectInputStream(file);
	      input.readObject();
	      ClientIDServer.retrieve(input);
	      return theater;
	    } catch(IOException ioe) {
	      ioe.printStackTrace();
	      return null;
	    } catch(ClassNotFoundException cnfe) {
	      cnfe.printStackTrace();
	      return null;
	    }
	  }
	  /**
	   * Serializes the Library object
	   * @return true iff the data could be saved
	   */
	  public static  boolean save() {
	    try {
	      FileOutputStream file = new FileOutputStream("TheaterData");
	      ObjectOutputStream output = new ObjectOutputStream(file);
	      output.writeObject(theater);
	      output.writeObject(ClientIDServer.instance());
	      return true;
	    } catch(IOException ioe) {
	      ioe.printStackTrace();
	      return false;
	    }
	  }
	  /**
	   * Writes the object to the output stream
	   * @param output the stream to be written to
	   */
	  private void writeObject(java.io.ObjectOutputStream output) {
	    try {
	      output.defaultWriteObject();
	      output.writeObject(theater);
	    } catch(IOException ioe) {
	      System.out.println(ioe);
	    }
	  }
	  /**
	   * Reads the object from a given stream
	   * @param input the stream to be read
	   */
	  private void readObject(java.io.ObjectInputStream input) {
	    try {
	      input.defaultReadObject();
	      if (theater == null) {
	        theater = (Theater) input.readObject();
	      } else {
	        input.readObject();
	      }
	    } catch(IOException ioe) {
	      ioe.printStackTrace();
	    } catch(Exception e) {
	      e.printStackTrace();
	    }
	  }
	  /** String form of the library
	  * 
	  */
	  @Override
	  public String toString() {
	    return theater + "\n" + clientList;
	  }
	
	  
	  /**
	   * Organizes the operations for adding a book
	   * @param title book title
	   * @param author author name
	   * @param id book id
	 * @return 
	   */
	  public Show addShow(String showName, String clientID, String startDate) {
	    Show show = new Show(showName, clientID, startDate);
	    showList.insertShow(show);     
		return show;

	    }

	/**
	*removes customer
	*@param customer
	*@return remove
	*/
	    public boolean removeCustomer(Customer customer) {
		  boolean remove = customerList.deleteCustomer(customer);
		  return remove;
	  }
	  /**
	*displays customer
	*/
	  public void displayCustomer() {
		  customerList.displayCustomer();
	  }
	  /**
	*Searches and return customer
	*@param customerName
	*@customer
	*/
	  public Customer searchCustomer(String customerName) {
		  Customer customer = customerList.search(customerName);
		  return customer;
	  }
	  
	/**
	*adds credit card to creditCardList
	*@param customerID
	*@param creditNumber
	*@param date
	*@return card
	*/
	  public CreditCard addCreditCard(String customerID, String creditNumber, String date) {
		  Customer customer = customerList.search(customerID);
		  CreditCard card = new CreditCard(customer.getId(), creditNumber, date);
		  creditCardList.addCard(card);
		  return card;
	  }
	  /**
	*removes credit card from list
	*@param customerID
	*@param creditNumber
	*@return check
	*/
	  public boolean deleteCreditCard(String customerID, String creditNumber) {
		  Customer customer = customerList.search(customerID);
		  boolean check = creditCardList.removeCard(customerID, creditNumber);
		  return check;
	  }

}

