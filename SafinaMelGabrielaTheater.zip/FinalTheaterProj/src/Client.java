import java.io.Serializable;
import java.io.*;
/* This the client class where the client object is made
 * 
 * @author Brahma Dathan and Sarnath Ramnath
 */
public class Client implements Serializable {
	
	private String name;
	private String address;
	private String phone;
	private String id;
	private double balance=0;
	private static final String CLIENT_STRING="C";
	public Client(String name,String address,String phone) {
		
		this.name=name;
		this.address=address;
		this.phone=phone;
		id=CLIENT_STRING + (ClientIDServer.instance().getId());
	}
	
	
	
	
	




	
	/* checks if the id is equal to the current id
	 * @param id
	 * returns a boolean depending if the ids are equal
	 */

	 public boolean equals(String id) {
		    
		 return this.id.equals(id);
		  }
	
	
	



	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}




	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}




	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}




	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}




	/**
	 * @return the phone
	 */
	public String getPhone() {
		return phone;
	}




	/**
	 * @param phone the phone to set
	 */
	public void setPhone(String phone) {
		this.phone = phone;
	}




	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}




	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}




	/**
	 * @return the balance
	 */
	public double getBalance() {
		return balance;
	}




	/**
	 * @param balance the balance to set
	 */
	public void setBalance(double balance) {
		this.balance = balance;
	}


	/*represents the string representation of the client object
	 * @param 
	 * returns the string representation
	 */

	@Override
	public String toString() {
		return "Client [name=" + name + ", address=" + address + ", phone=" + phone + ", id=" + id + ", balance="
				+ balance + "]";
	}

	
	
	
	
	

}

