/**
 * CustomerList class keeps a list of customers
 * @author Ella@author Brahma Dathan and Sarnath Ramnath
 */
import java.io.IOException;
import java.io.Serializable;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class CustomerList implements Serializable {
	
	private static final long SERIAL_VERSION_UID = 1L;
	
	private List<Customer> customers = new LinkedList<Customer>();
	private static CustomerList customerList;
		/**
	 * 
	 * @author Brahma Dathan and Sarnath Ramnath
	 * @Copyright (c) 2010
	 
	 * Redistribution and use with or without
	 * modification, are permitted provided that the following conditions
	 * are met:
	 *
	 *   - the use is for academic purpose only
	 *   - Redistributions of source code must retain the above copyright
	 *     notice, this list of conditions and the following disclaimer.
	 *   - Neither the name of Brahma Dathan or Sarnath Ramnath
	 *     may be used to endorse or promote products derived
	 *     from this software without specific prior written permission.
	 *
	 * The authors do not make any claims regarding the correctness of the code in this module
	 * and are not responsible for any loss or damage resulting from its use.  
	 */

	/**
	 * The collection class for Book objects
	 * @author Brahma Dathan and Sarnath Ramnath
	 *
	 */
	  private static final long serialVersionUID = 1L;
	  private List<CreditCard> listOfCreditCards = new LinkedList<CreditCard>();
	  private static CreditCardList catalog;
	  /*
	   * Private constructor for singleton pattern
	   * 
	   */
	private CustomerList() {
	}
	  /**
	   * Supports the singleton pattern
	   * 
	   * @return the singleton object
	   */
	public static CustomerList instance() {
		if(customerList == null) {
			return (customerList = new CustomerList());
		} else {
			return customerList;
		}
	}
	
	  /**
	   * Checks whether a book with a given book id exists.
	   * @param bookId the id of the book
	   * @return true iff the book exists
	   * 
	   */
	public Customer search(String customerName) {
		for(Iterator<Customer> iterator = customers.iterator();
				iterator.hasNext(); ) {
			Customer customer = (Customer) iterator.next();
			if(customer.getName().equals(customerName)) {
				return customer;
			}
		}
		return null;
	}
	
	  /**
	   * Removes a book from the catalog
	   * @param bookId book id
	   * @return true iff book could be removed
	   */
	public boolean insertedCustomer(Customer customer) {
		customers.add(customer);
		return true;
	}
	
	  /**
	   * Removes a book from the catalog
	   * @param bookId book id
	   * @return true iff book could be removed
	   */
	public boolean deleteCustomer(Customer customer) {
		customers.remove(customer);
		return true;
	}
	
	/**
	*displays customer
	*/
public void displayCustomer() {
		for(int i = 0; i < customers.size(); i++) {
			System.out.println(customers.toString());
		}
	}
	  /*
	   * Supports serialization
	   * @param output the stream to be written to
	   */
	  private void writeObject(java.io.ObjectOutputStream output) {
		    try {
		      output.defaultWriteObject();
		      output.writeObject(customerList);
		    } catch(IOException ioe) {
		      ioe.printStackTrace();
		    }
		  }
		  /*
		   * Supports serialization
		   *  @param input the stream to be read from
		   */
		  private void readObject(java.io.ObjectInputStream input) {
		    try {
		      if (customerList != null) {
		        return;
		      } else {
		        input.defaultReadObject();
		        if (customerList == null) {
		          customerList = (CustomerList) input.readObject();
		        } else {
		          input.readObject();
		        }
		      }
		    } catch(IOException ioe) {
		      ioe.printStackTrace();
		    } catch(ClassNotFoundException cnfe) {
		      cnfe.printStackTrace();
		    }
		  }
		  /** String form of the collection
		  * 
		  */
		  @Override
		  public String toString() {
		    return customers.toString();
		  }
}
