/**
 * Show class holds info on show being booked
 * @author @author Brahma Dathan and Sarnath Ramnath
 */
import java.io.Serializable;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Iterator;
import java.util.*;

public class Show implements Serializable {
private static final long serialVersionUID = 1L;
private String showName = "";
private String clientID;
private String dateRange;
private LinkedList<Show> listOfShows = new LinkedList<Show>();

/**
 * Show() constructor Creates a show with a name, ID, and start/end date
 * @param showName name of the show
 * @param clientID unique ID of client
 * @param dateRange is the range of dates for show
 */
public Show(String showName, String clientID, String dateRange) {
	super();
	this.showName = showName;
	this.clientID = clientID;
	this.dateRange = dateRange;
}

/**
 * getShowName() retrieves name of show
 * @return showName title of show
 */
public String getShowName() {
	return showName;
}


public void setShowName(String showName) {
	this.showName = showName;
}

/**
 * getShowName() retrieves clientID
 * @return clientID ID of client
 */
public String getClientID() {
	return clientID;
}


public void setClientID(String clientID) {
	this.clientID = clientID;
}

/**
 * getShowName() retrieves dateRange
 * @return dateRange date range of play
 */
public String getStartDate() {
	return dateRange;
}


public void setStartDate(String dateRange) {
	this.dateRange = dateRange;
}

/**
 * getSerialversionuid() gets the id 
 * @return serialVersionUID
 */
public static long getSerialversionuid() {
	return serialVersionUID;
}


/**
 * Checks whether a client with a given client id exists.
 * @param clientId the id of the client
 * @return true iff client exists
 * 
 */

public Show search(String clientId) {
  for(
	Iterator<Show> iterator = listOfShows.iterator(); iterator.hasNext(); ) {
    Show show = (Show) iterator.next();
    if (show.getShowName().equals(clientId)) {
      return show;
    }
  }
  return null;
}


@Override
public String toString() {
	return "\n" + "Shows name: " + showName + "\t Client ID: " + clientID + "\t Date Range: " + dateRange + "\n";
}









	
}



