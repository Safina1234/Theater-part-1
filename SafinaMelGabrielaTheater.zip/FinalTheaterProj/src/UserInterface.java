/**This is the UserInterface class which the command line interface id made
 * The user will type a command and the interface will go to the respected command 
 * @author Brahma Dathan and Sarnath Ramnath

 **/

import java.util.*;
import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.StringTokenizer;
import java.io.Serializable;


public class UserInterface implements Serializable {
	  private static final int EXIT = 0;
	  private static final int ADD_CLIENT = 1;
	  private static final int REMOVE_CLIENT = 2;
	  private static final int LIST_ALL_CLIENTS = 3;
	  private static final int ADD_CUSTOMER = 4;
	  private static final int REMOVE_CUSTOMER = 5;
	  private static final int ADD_CREDIT_CARD = 6;
	  private static final int REMOVE_CREDIT_CARD = 7;
	  private static final int LIST_ALL_CUSTOMERS = 8;
	  private static final int ADD_A_SHOW = 9;
	  private static final int LIST_ALL_SHOWS = 10;
	  private static final int STORE_DATA = 11;
	  private static final int RETRIEVE_DATA = 12;
	  private static final int HELP = 13;
	
	  private static UserInterface userInterface;
	  private BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
	  private static Theater theater;
	  
	  /**
	   * UserInterface() looking for saved data
	   * 
	   */
	  private UserInterface() {
	    if (yesOrNo("Look for saved data and  use it?")) {
	      retrieve();
	    } else {
	      theater = theater.instance();
	    }
	  }
	  /**
	   * Supports the singleton pattern
	   * 
	   * @return the singleton object
	   */
	  public static UserInterface instance() {
	    if (userInterface == null) {
	      return userInterface = new UserInterface();
	    } else {
	      return userInterface;
	    }
	  }
	  
	  
	  /**
	   * Queries for a yes or no and returns true for yes and false for no
	   * 
	   * @param prompt The string to be prepended to the yes/no prompt
	   * @return true for yes and false for no
	   * 
	   */
	  private boolean yesOrNo(String prompt) {
	    String more = getToken(prompt + " (Y|y)[es] or anything else for no");
	    if (more.charAt(0) != 'y' && more.charAt(0) != 'Y') {
	      return false;
	    }
	    return true;
	  }
	  
	  public Calendar getDate(String prompt) {
		    do {
		      try {
		        Calendar date = new GregorianCalendar();
		        String item = getToken(prompt);
		        DateFormat dateFormat = SimpleDateFormat.getDateInstance(DateFormat.SHORT);
		        date.setTime(dateFormat.parse(item));
		        return date;
		      } catch (Exception fe) {
		        System.out.println("Please input a date as mm/dd/yy");
		      }
		    } while (true);
		  }
	
	  public String getToken(String prompt) {
		    do {
		      try {
		        System.out.println(prompt);
		        String line = reader.readLine();
		        StringTokenizer tokenizer = new StringTokenizer(line,"\n\r\f");
		        if (tokenizer.hasMoreTokens()) {
		          return tokenizer.nextToken();
		        }
		      } catch (IOException ioe) {
		        System.exit(0);
		      }
		    } while (true);
		  }
	  
	  /**
	   * Prompts for a command from the keyboard
	   * 
	   * @return a valid command
	   * 
	   */
	  public int getCommand() {
	    do {
	      try {
	        int value = Integer.parseInt(getToken("Enter command:" + HELP + " for help"));
	        if (value >= EXIT && value <= HELP) {
	          return value;
	        }
	      } catch (NumberFormatException nfe) {
	        System.out.println("Enter a number");
	      }
	    } while (true);
	  }
	  /**
	   * Displays the help screen
	   * 
	   */
	  public void help() {
	    System.out.println("Enter a number between 0 and 12 as explained below:");
	    System.out.println(EXIT + " to Exit\n");
	    System.out.println(ADD_CLIENT + " to add a client");
	    System.out.println(REMOVE_CLIENT + " to remove client");
	    System.out.println(LIST_ALL_CLIENTS + " to list all clients");
	    System.out.println(ADD_CUSTOMER + " to  add customers");
	    System.out.println(REMOVE_CUSTOMER + " to remove customer");
	    System.out.println(ADD_CREDIT_CARD + " to add credit card");
	    System.out.println(REMOVE_CREDIT_CARD + " to remove credit card");
	    System.out.println(LIST_ALL_CUSTOMERS + " to list all customers");
	    System.out.println(ADD_A_SHOW + " to add a show");
	    System.out.println(LIST_ALL_SHOWS + " to list all shows");
	    System.out.println(STORE_DATA + " to store date");
	    System.out.println(RETRIEVE_DATA + " to  retrieve data");
	    System.out.println(HELP + " for help");
	  }
	  
/* Removes a client to the client list if the client doesn�t have a show scheduled
*@param 
*returns nothing
*/
	  
  public void removeClient() {
		  
		  String clientId=getToken("Enter client Id");
		  Show show=theater.searchShow(clientId);
		  Client client=theater.searchClient(clientId);
		  
		  if(show==null) {
			  
			 theater.removeClient(client); 
		  }
		  
		  else {
		  if(show.getClientID().equals(client.getId())) {
				  
				  System.out.println("Cannot remove Client");
			  }
		   
		  }
	  }
	  
	  



		
		
	  
	  /**
	   * Method to be called for adding a show.
	   * Prompts the user for the appropriate values and
	   * uses the appropriate Theater method for adding the show.
	   *  
	   */
	  public void addShow() {
	    Show result;
	    do {
	      String showName = getToken("Enter  show name");
	      String clientID = getToken("Enter client ID: ");
	      String startDate = getToken("Enter start date: ");
	      result = theater.addShow(showName, clientID, startDate);
	      if (result != null) {
	        System.out.println(result);
	      } else {
	        System.out.println("Show could not be added");
	      }
	      if (!yesOrNo("Add more shows?")) {
	        break;
	      }
	    } while (true);
	  }
	  
/* Adds a client to the client list
*@param 
*returns nothing
*/
	  public void addClient() {
		    String name = getToken("Enter client name");
		    String address = getToken("Enter address");
		    String phone = getToken("Enter phone");
		    Client result;
		    result = theater.addClient(name, address, phone);
		    if (result == null) {
		      System.out.println("Could not add client");
		    }
		    System.out.println(result);
		  }
	  
	  

	  
/* Displays the clients on the client list
*@param 
*returns nothing
*/


  public void displayClient() {
		  
		  theater.displayClients();
		  
	  }
	  /**
	*adds customer and shows results
	*/
	  public void addCustomer() {
			    String nameP = getToken("Enter customer name");
			    String addressP = getToken("Enter address");
			    String phoneP = getToken("Enter phone");
			    String creditNumberP = getToken("Enter credit card number");
			    String creditDateP = getToken("Enter credit card date");
			    Customer result = theater.addCustomer(nameP, addressP, phoneP, creditNumberP, creditDateP);
			    if (result == null) {
			      System.out.println("Could not add customer");
			    }
			    System.out.println(result);
			 
	  }


	 /* public void addCustomer() {
			    String nameP = getToken("Enter customer name");
			    String addressP = getToken("Enter address");
			    String phoneP = getToken("Enter phone");
			    String creditNumberP = getToken("Enter credit card number");
			    String creditDateP = getToken("Enter credit card date");
			    Customer result = null;
			    //Integer credit = 0 , date = 0;
			   // credit = Integer.parseInt(creditNumber);
			   // date = Integer.parseInt(creditDate);
			    result = theater.addCustomer(result.getName(), result.getAddress(), result.getPhone(), result.getCreditNumber(), result.getCreditDate());
			    if (result == null) {
			      System.out.println("Could not add customer");
			    }
			    System.out.println(result);
			 
	  }*/
	/**
*removes Customer and shows results
*/  
	  public void removeCustomer() {
		  String name = getToken("Enter name");
		  Customer customer = theater.searchCustomer(name);
		  boolean remove = theater.removeCustomer(customer);
		  if (remove == false) {
			  System.out.println("Could not remove customer");
		  }
		  System.out.println("Removed customer");
	  }

	/**
*Adds credit card and displays results
*/  
	  public void addCreditCard() {
		  String name = getToken("Enter customer name");
		  Customer customer = theater.searchCustomer(name);
		  String creditNumber = getToken("Enter credit card number");
		  String creditDate = getToken("Enter credit card date");
		  CreditCard add = theater.addCreditCard(customer.getName(), creditNumber, creditDate);
		  if (add == null) {
		    System.out.println("Could not add customer credit card");
		  }
		  System.out.println("Added customer credit card");
		  
	  }

	  /**
	*removes credit card and shows results
	*/
	  public void removeCreditCard() {
		  String name = getToken("Enter name");
		  Customer customer = theater.searchCustomer(name);
		  String card = getToken("Enter credit card");
		  boolean remove = theater.deleteCreditCard(customer.getId(), card);
		  if (remove == false) {
			  System.out.println("Could not remove credit card" +
					  "\nCustomer has only one credit card");
		  }
		  System.out.println("Removed credit card");
	  }

	/**
*shows customers
*/  
	  public void displayCustomers() {
		  theater.displayCustomer();
	  }
	  
	  public void listAllShows() {
		  
			System.out.println(theater.displayShows());
		}
	  
	  /**
	   * Method to be called for saving the Library object.
	   * Uses the appropriate Library method for saving.
	   *  
	   */
	  private void save() {
	    if (theater.save()) {
	      System.out.println(" The library has been successfully saved in the file TheaterData \n" );
	    } else {
	      System.out.println(" There has been an error in saving \n" );
	    }
	  }
	  /**
	   * Method to be called for retrieving saved data.
	   * Uses the appropriate Library method for retrieval.
	   *  
	   */
	  private void retrieve() {
	    try {
	      Theater tempTheater = theater.retrieve();
	      if (tempTheater != null) {
	        System.out.println(" The library has been successfully retrieved from the file TheaterData \n" );
	        theater = tempTheater;
	      } else {
	        System.out.println("File doesnt exist; creating new library" );
	        theater = Theater.instance();
	      }
	    } catch(Exception cnfe) {
	      cnfe.printStackTrace();
	    }
	  }
	  /**
	   * Orchestrates the whole process.
	   * Calls the appropriate method for the different functionalties.
	   *  
	   */
	  public void process() {
	    int command;
	    help();
	    while ((command = getCommand()) != EXIT) {
	      switch (command) {
	        case ADD_CLIENT:        addClient();
	                                break;
	        case REMOVE_CLIENT:         //removeClient();
	                                break;
	        case LIST_ALL_CLIENTS:       displayClient();
	                                break;
	        case ADD_CUSTOMER:      addCustomer();
	                                break;
	        case REMOVE_CUSTOMER:      removeCustomer();
	                                break;
	        case ADD_CREDIT_CARD:       addCreditCard();
	                                break;
	        case REMOVE_CREDIT_CARD:        removeCreditCard();
	                                break;
	        case LIST_ALL_CUSTOMERS:       displayCustomers();
	                                break;
	        case ADD_A_SHOW:      addShow();
	                                break;
	        case LIST_ALL_SHOWS:  listAllShows();
	                                break;
	        case STORE_DATA:              save();
	                                break;
	        case RETRIEVE_DATA:          retrieve();
	                                break;
	        case HELP:              help();
	                                break;
	      }
	    }
	  }
	  /**
	   * The method to start the application. Simply calls process().
	   * @param args not used
	   */
	  public static void main(String[] args) {
	    UserInterface.instance().process();
	  }
	}

